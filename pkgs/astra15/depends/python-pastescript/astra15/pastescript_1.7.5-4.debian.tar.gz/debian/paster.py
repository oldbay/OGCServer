#!/usr/bin/python

from paste.script import command
command.run()
