from PIL.ImagePalette import *
